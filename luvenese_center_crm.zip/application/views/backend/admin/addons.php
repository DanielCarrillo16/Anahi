<a href="<?php echo site_url('admin/addon/add'); ?>" 
    class="btn btn-primary pull-right btn-adding">
        <i class="entypo-user-add"></i>
        <?php echo get_phrase('add_new_addon');?>
    </a>
     
<br><br>

<div class="main_data">
  <?php include "addon_list.php"; ?>
</div>